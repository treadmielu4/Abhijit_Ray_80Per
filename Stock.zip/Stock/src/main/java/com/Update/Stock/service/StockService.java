package com.Update.Stock.service;

import com.Update.Stock.entity.Stock;

public interface StockService {

	public Iterable<Stock> getAllStock();
	public Stock getStockById(int stock_id);
	//public Stock getStockByName(String stock_name);
}
