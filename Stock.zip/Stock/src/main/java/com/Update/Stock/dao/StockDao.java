package com.Update.Stock.dao;

import java.util.List;

import com.Update.Stock.entity.Stock;

public interface StockDao {
	public List<Stock> getAllStock();
	public Stock getStockById(int stock_id);
	//public Stock getStockByName(String stock_name);

}
